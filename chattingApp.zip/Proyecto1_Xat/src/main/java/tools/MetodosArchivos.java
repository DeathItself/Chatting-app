/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tools;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Ruben
 */
public class MetodosArchivos {

    public static void main(String[] args) throws SQLException, Exception {
//          Date fecha = Date.valueOf("2023-10-14");
//          crearArchivos("Ruben",fecha,"ArchivoReal","C:/Archivos/ArchivoReal.txt");
            borrarArchivo("Ruben");
    }
public static void crearArchivos(int emmisor,String nomReal, String rutaArxiu) throws SQLException, IOException {
        try ( Connection conexion = tools.ConexionJDBC.conectarJDB()) {
            String sequencia = "INSERT INTO fitxers(emissor,receptor,fecha,nomReal,rutaArxiu,permis)VALUES (?,?,NOW(),?,?,?)";
            PreparedStatement ps = conexion.prepareStatement(sequencia);
            ps.setInt(1, emmisor);
            ps.setString(2, null);
            ps.setString(3, nomReal);
            ps.setString(4, rutaArxiu);
            ps.setString(5, "Protected");
            ps.executeUpdate();
            ps.close();
        } catch (SQLException ex) {
            Logger.getLogger(MetodosArchivos.class.getName()).log(Level.SEVERE, null, ex);
        }

    }
    
    public static String nomUsuario(int id) throws Exception {
        String nom = null;
        try ( Connection conexion = tools.ConexionJDBC.conectarJDB()) {
            PreparedStatement idUser = conexion.prepareStatement("SELECT nom FROM usuarios WHERE id = ?");
            idUser.setInt(1, id);
            idUser.executeQuery();
            ResultSet resultat = idUser.getResultSet();
            if (resultat.next()) {
                System.out.println(resultat.getString(1));
                nom = resultat.getString(1);
            } else {
                throw new Exception("El usuario no existe");
            }
            resultat.close();
            idUser.close();
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
        return nom;

    }
    
    public static String nomGrup(int id) throws Exception {
        String nom = null;
        try ( Connection conexion = tools.ConexionJDBC.conectarJDB()) {
            PreparedStatement idGrup = conexion.prepareStatement("SELECT nom FROM grupos WHERE id = ?");
            idGrup.setInt(1, id);
            idGrup.executeQuery();
            ResultSet resultat = idGrup.getResultSet();
            if (resultat.next()) {
                System.out.println(resultat.getString(1));
                nom = resultat.getString(1);
            } else {
                throw new Exception("El usuario no existe");
            }
            resultat.close();
            idGrup.close();
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
        return nom;

    }
    
    public static void enviaArchivo(int idFitxer,String receptor,int idReceptor) throws Exception {
        try ( Connection conexion = tools.ConexionJDBC.conectarJDB()) {
            if (receptor == "cliente" || receptor == "Cliente") {
                String user = nomUsuario(idReceptor);
                PreparedStatement ps = conexion.prepareStatement("UPDATE fitxers SET receptor = ? AND permis = ? WHERE id = ?");
                ps.setString(1, user);
                ps.setString(2, "Private");
                ps.setInt(3, idFitxer);
                ps.executeUpdate();
                ps.close();
            } else if (receptor == "grupo" || receptor == "Grupo") {
                String group = nomGrup(idReceptor);
                PreparedStatement ps = conexion.prepareStatement("UPDATE fitxers SET receptor = ? AND permis = ? WHERE id = ?");
                ps.setString(1, group);
                ps.setString(2, "Public");
                ps.setInt(3, idFitxer);
                ps.executeUpdate();
                ps.close();
            } else {
                throw new Exception("Error el receptor seleccionado no es ni cliente ni un grupo");
            }
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }

    }
     public static String compruebaCreador(int id) throws SQLException, IOException{
        String nomCreadors = "";
        try(Connection conexion = tools.ConexionJDBC.conectarJDB()){
            String sequencia = "SELECT emissor FROM fitxers WHERE id = ?";
            PreparedStatement ps = conexion.prepareStatement(sequencia);
            ps.setInt(1, id);
            ps.executeQuery();
            ResultSet rs = ps.getResultSet();
            while(rs.next()){
                nomCreadors = rs.getString(1);
            }
        } 
        return nomCreadors;
    }
    
    public static void enviaArchivos(int numeroID, String receptor, int id) throws SQLException, IOException {
        try ( Connection conexion = tools.ConexionJDBC.conectarJDB()) {
//            int nomReceptor = 0;
            String permiso = null;
            if (receptor.equals("cliente") || receptor.equals("Cliente")) {
                permiso = "Private";
//                PreparedStatement ps = conexion.prepareStatement("SELECT nom FROM usuarios WHERE id = ?");
//                ps.setInt(1, numeroID);
//                ps.executeQuery();
//                ResultSet rs = ps.getResultSet();
//                if (rs.next()) {
//                    nomReceptor = rs.getInt(1);
//                } else {
//                    System.out.println("El usuario no existe");
//                }
//                ps.close();
            } else if (receptor.equals("grupo") || receptor.equals("Grupo")) {
                permiso = "Public";
//                PreparedStatement ps = conexion.prepareStatement("SELECT nom FROM grupos WHERE id = ?");
//                ps.setInt(1, numeroID);
//                ps.executeQuery();
//                ResultSet rs = ps.getResultSet();
//                if (rs.next()) {
//                    nomReceptor = rs.getInt(1);
//                } else {
//                    System.out.println("El grupo no existe");
//                }
//                ps.close();
            }
            PreparedStatement ps2 = conexion.prepareStatement("UPDATE fitxers SET receptor = ? , permis = ? WHERE id = "+id);
            ps2.setInt(1,numeroID);
            ps2.setString(2,permiso);
            ps2.executeUpdate();
            ps2.close();
        }
    }
    
    public static void borrarArchivo(String usuario) throws SQLException, Exception {
        try(Connection conexion = tools.ConexionJDBC.conectarJDB()){
            int idFitxer = 0;
            PreparedStatement ps = conexion.prepareStatement("SELECT id FROM fitxers WHERE Emissor = ?");
            ps.setString(1, usuario);
            ps.executeQuery();
            ResultSet rs = ps.getResultSet();
            if(rs.next()){
                System.out.println(rs.getInt(1));
                idFitxer = rs.getInt(1);
            }
            else{
                throw new Exception("el archivo no existe");
            }
            rs.close();
            ps.close();
            
            PreparedStatement ps2 = conexion.prepareStatement("DELETE FROM fitxers WHERE id = ?");
            ps2.setInt(1, idFitxer);
            ps2.executeUpdate();
            ps2.close();
        }   
    }
}

