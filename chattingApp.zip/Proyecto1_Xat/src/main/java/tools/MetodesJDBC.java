/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tools;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;

/**
 *
 */
public class MetodesJDBC {

    //CONSULTA
    /**
     * CONSULTAR ID y NOMBRE Devuelve un resultado si la variable es igual
     *
     * @param id
     * @param nom
     * @param consulta
     * @return
     * @throws java.sql.SQLException
     * @throws java.io.IOException
     */
    public static String[] consultarIdNom(int id, String nom, String consulta) throws SQLException, IOException {
        String[] grupoConsulta = new String[2];
        try ( Connection conexion = tools.ConexionJDBC.conectarJDB()) {
            PreparedStatement ps;
            if (id != 0) {
                ps = conexion.prepareStatement("SELECT id,nom FROM " + consulta + " WHERE id LIKE ?");
                ps.setInt(1, id);
            } else if (nom != null) {
                ps = conexion.prepareStatement("SELECT id,nom FROM " + consulta + " WHERE nom LIKE ?");
                ps.setString(1, nom);
            } else {
                return null;
            }
            ps.executeQuery();
            ResultSet rs = ps.getResultSet();
            if (rs.next()) {
                grupoConsulta[0] = Integer.toString(rs.getInt(1));
                grupoConsulta[1] = rs.getString(2);
            }
            rs.close();
            ps.close();
            return grupoConsulta;
        }
    }

    //USUARIO
    /**
     * CREA UN USUARIO Crea un registro en Usuarios de la DDBB.
     *
     * @param nom
     * @param contrasenya
     * @throws java.sql.SQLException
     * @throws java.io.IOException
     */
    public static void insertarUsuari(String nom, String contrasenya) throws SQLException, IOException {
        try ( Connection conexion = tools.ConexionJDBC.conectarJDB()) {
            PreparedStatement ps = conexion.prepareStatement("INSERT INTO usuarios(nom,contrasenya) VALUES (?,?)");
            ps.setString(1, nom);
            ps.setString(2, contrasenya);
            ps.executeUpdate();
            ps.close();
        }
    }

    /**
     * LISTAR NOMBRES DE USUARIOS Obtiene una lista de nombres de usuarios desde
     * la base de datos.
     *
     * @return Un ArrayList que contiene los nombres de usuarios.
     * @throws SQLException Si ocurre un error al ejecutar la consulta SQL.
     * @throws java.io.IOException
     */
    public static ArrayList<String> llistarUsuaris() throws SQLException, IOException {
        ArrayList<String> nombresUsuarios = new ArrayList<>();

        try ( Connection conexion = tools.ConexionJDBC.conectarJDB()) {
            PreparedStatement ps = conexion.prepareStatement("SELECT Nom FROM usuarios");
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                nombresUsuarios.add(rs.getString("Nom"));
            }
        }

        return nombresUsuarios;
    }

    // Nuevo método para actualizar la lista de usuarios cada 1 minuto
    /*
    public static void actualizarListaUsuarios() {
        ScheduledExecutorService scheduler = Executors.newScheduledThreadPool(1);

        // Programa la tarea para ejecutarse cada 1 minuto
        scheduler.scheduleAtFixedRate(() -> {
            try {
                ArrayList<String> nuevosUsuarios = llistarUsuaris(); //recibimos un array actualizado con los clientes
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }, 0, 1, TimeUnit.MINUTES);
    }
     */
    /**
     * CONSULTAR USUARIO Devuelve un resultado si la variable es igual
     *
     * @param user
     * @param contrasena
     * @return
     * @throws java.sql.SQLException
     * @throws java.io.IOException
     */
    public static String consultarUsuari(String user, String contrasena) throws SQLException, IOException {
        String nombreConsulta = null;
        try ( Connection conexion = tools.ConexionJDBC.conectarJDB()) {
            PreparedStatement ps = conexion.prepareStatement("SELECT nom FROM usuarios WHERE nom = ? AND Contrasenya = ?");
            ps.setString(1, user);
            ps.setString(2, contrasena);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                nombreConsulta = rs.getString(1);
            }
            rs.close();
            ps.close();
            return nombreConsulta;
        }
    }

    /**
     * MODIFICAR USUARIO Modifica nombre usuario
     *
     * @param user
     * @param nomMod
     * @throws java.sql.SQLException
     * @throws java.io.IOException
     */
    public static void modificarUsuari(String user, String nomMod) throws SQLException, IOException {
        try ( Connection conexion = tools.ConexionJDBC.conectarJDB()) {
            PreparedStatement ps = conexion.prepareStatement("UPDATE usuarios SET nom = ? WHERE nom =?");
            ps.setString(1, nomMod);
            ps.setString(2, user);
            ps.executeUpdate();
            ps.close();
        }
    }

    //GRUPO
    /**
     * CREAR GRUPO Crea un grupo a la DDBB
     *
     * @param grupo
     * @throws java.sql.SQLException
     * @throws java.io.IOException
     */
    public static void insertarGrup(String grupo) throws SQLException, IOException {
        try ( Connection conexion = tools.ConexionJDBC.conectarJDB()) {
            PreparedStatement ps = conexion.prepareStatement("INSERT INTO grupos(nom) VALUES (?)");
            ps.setString(1, grupo);
            ps.executeUpdate();
            ps.close();
        }
    }

    /**
     * ELIMINA UN GRUPO Elimina un grupo sin herencia
     *
     * @param idGrupo
     * @throws java.sql.SQLException
     * @throws java.io.IOException
     */
    public static void eliminaGrupo(int idGrupo) throws SQLException, IOException {
        try ( Connection conexion = tools.ConexionJDBC.conectarJDB()) {
            PreparedStatement ps = conexion.prepareStatement("DELETE FROM Grupos WHERE id LIKE ?");
            ps.setInt(1, idGrupo);
            ps.executeUpdate();
            ps.close();
        }
    }

    //ROLES
    /**
     * INSERTA UN ROL Inserta un rol con las id de Usuario y Grupo así como el
     * tipo de rol
     *
     * @param idUsuario
     * @param idGrupo
     * @param permiso
     * @throws java.sql.SQLException
     * @throws java.io.IOException
     */
    public static void insertarRol(int idUsuario, int idGrupo, String permiso) throws SQLException, IOException {
        if (idUsuario != 0 && idGrupo != 0) {
            try ( Connection conexion = tools.ConexionJDBC.conectarJDB()) {
                PreparedStatement ps = conexion.prepareStatement("INSERT INTO roles(idUsuari, idGrup, tipo, fecha) VALUES (?,?,?,NOW())");
                ps.setInt(1, idUsuario);
                ps.setInt(2, idGrupo);
                ps.setString(3, permiso);
                ps.executeUpdate();
                ps.close();
            }
        }
    }

    /**
     * ELIMINA UN ROL Elimina un rol con las id de Usuario y Grupo
     *
     * @param idUsuario
     * @param idGrupo
     * @throws java.sql.SQLException
     * @throws java.io.IOException
     */
    public static void eliminaRol(int idUsuario, int idGrupo) throws SQLException, IOException {
        try ( Connection conexion = tools.ConexionJDBC.conectarJDB()) {
            if (idUsuario != 0 && idGrupo != 0) {
                PreparedStatement ps = conexion.prepareStatement("DELETE FROM roles WHERE idUsuari LIKE ? AND idGrup LIKE ?");
                ps.setInt(1, idUsuario);
                ps.setInt(2, idGrupo);
                ps.executeUpdate();
                ps.close();
            }
        }
    }

    /**
     * ELIMINA ROLES Elimina los roles de un grupo sin herencia
     *
     * @param idGrupo
     * @throws java.sql.SQLException
     * @throws java.io.IOException
     */
    public static void eliminaRolesCascada(int idGrupo) throws SQLException, IOException {
        //int idGrupo = 0;
        try ( Connection conexion = tools.ConexionJDBC.conectarJDB()) {
            PreparedStatement ps = conexion.prepareStatement("DELETE FROM roles WHERE idGrup LIKE ?");
            ps.setInt(1, idGrupo);
            ps.executeUpdate();
            ps.close();
        }
    }

    /**
     * CONSULTA ROL Return los datos de un usuario en un grupo
     *
     * @param idUsuario
     * @param idGrupo
     * @return
     * @throws java.sql.SQLException
     * @throws java.io.IOException
     */
    public static String[] consultaRol(int idUsuario, int idGrupo) throws SQLException, IOException {
        String[] arrayConsulta = new String[3];
        SimpleDateFormat formato = new SimpleDateFormat("yyyy/MM/dd");
        if (idUsuario != 0 && idGrupo != 0) {
            try ( Connection conexion = tools.ConexionJDBC.conectarJDB()) {
                PreparedStatement ps = conexion.prepareStatement("SELECT id, tipo, fecha FROM roles WHERE idUsuari LIKE ? AND idGrup LIKE ?");
                ps.setInt(1, idUsuario);
                ps.setInt(2, idGrupo);
                ps.executeQuery();
                ResultSet rs = ps.getResultSet();
                if (rs.next()) {
                    arrayConsulta[0] = rs.getString(1);
                    arrayConsulta[1] = rs.getString(2);
                    String fechaConFormato = formato.format(rs.getDate(3));
                    arrayConsulta[2] = fechaConFormato;
                }
                rs.close();
                ps.close();
                return arrayConsulta;
            }
        }
        return null;
    }

    /**
     * MODIFICAR ROL Modifica el premiso de un usuario dentro de Roles
     *
     * @param id
     * @param permiso
     * @throws java.sql.SQLException
     * @throws java.io.IOException
     */
    public static void modificarRol(int id, String permiso) throws SQLException, IOException {
        try ( Connection conexion = tools.ConexionJDBC.conectarJDB()) {
            PreparedStatement ps = conexion.prepareStatement("UPDATE roles SET tipo = ? WHERE id =?");
            ps.setString(1, permiso);
            ps.setInt(2, id);
            ps.executeUpdate();
            ps.close();
        }
    }

    /**
     * ELIMINA ROL Elimina los Roles de un usuario dentro de un Grupo
     *
     * @param idUsuario
     * @param idGrupo
     * @throws java.sql.SQLException
     * @throws java.io.IOException
     */
    public static void eliminarRol(int idUsuario, int idGrupo) throws SQLException, IOException {
        try ( Connection conexion = tools.ConexionJDBC.conectarJDB()) {
            PreparedStatement ps = conexion.prepareStatement("DELETE roles WHERE idUsuari = ? AND idGrup =?");
            ps.setInt(1, idUsuario);
            ps.setInt(2, idGrupo);
            ps.executeUpdate();
            ps.close();
        }
    }

    /**
     * LISTA ORDENADA ROLES Con los nombres de Usuario y Grupo
     *
     * @param idGrupo
     * @return
     * @throws java.sql.SQLException
     * @throws java.io.IOException
     */
    public static ArrayList<String[]> listaOrdenadaRoles(int idGrupo) throws SQLException, IOException {
        ArrayList<String[]> matriz = new ArrayList<String[]>();
        SimpleDateFormat formato = new SimpleDateFormat("yyyy/MM/dd");
        try ( Connection conexion = tools.ConexionJDBC.conectarJDB()) {
            PreparedStatement ps = conexion.prepareStatement("SELECT id, idUsuari, tipo, fecha FROM roles WHERE idGrup LIKE ?");
            ps.setInt(1, idGrupo);
            ps.executeQuery();
            ResultSet rs = ps.getResultSet();
            while (rs.next()) {
                String fechaDesordenada = formato.format(rs.getDate("fecha"));
                matriz.add(new String[]{rs.getString("id"), rs.getString("idUsuari"), rs.getString("tipo"), fechaDesordenada});
            }
            Collections.sort(matriz, Comparator.comparing(fechaOrdenada -> fechaOrdenada[2]));
            rs.close();
            ps.close();
            return matriz;
        }
    }

    //MENSAJE
    /**
     * CREA UN MENSAJE Con la direccion y el contenido
     *
     * @param from
     * @param to
     * @param contenido
     * @throws java.sql.SQLException
     * @throws java.io.IOException
     */
    public static void insertarMensaje(int from, int to, String contenido) throws SQLException, IOException {
        try ( Connection conexion = tools.ConexionJDBC.conectarJDB()) {
            PreparedStatement ps = conexion.prepareStatement("INSERT INTO mensajes(emissor, receptor, missatge, fecha) VALUES (?,?,?,NOW())");
            ps.setInt(1, from);
            ps.setInt(2, to);
            ps.setString(3, contenido);
            ps.executeUpdate();
            ps.close();
        }
    }
}
