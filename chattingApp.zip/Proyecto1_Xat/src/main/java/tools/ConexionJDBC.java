/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tools;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Ruben
 */
public class ConexionJDBC {

    private static String adrecaIP = "localhost";
    private static int puerto = 3306;
    private static String baseDades = "xat";
    private static String usuari = "root";
    //private static String contrasenya = "1234";
    private static String contrasenya = "root";

    public static Connection conectarJDB() throws SQLException, IOException {
        //setConexion();
        Connection conexion = DriverManager.getConnection("jdbc:mysql://" + adrecaIP + ":" + puerto + "/" + baseDades, usuari, contrasenya);
        return conexion;
    }

    private static void setConexion() throws IOException {
        String fileName = "servidor.conf";
        if (Files.exists(Paths.get(fileName))) {
            //LEER
            List<String> linesLeer = Files.readAllLines(Paths.get(fileName), StandardCharsets.UTF_8);
            int maxBytesDefecto = Integer.parseInt(linesLeer.get(0));
            int maxConexionesDefecto = Integer.parseInt(linesLeer.get(1));
            ConexionJDBC.contrasenya = linesLeer.get(2);
            ConexionJDBC.usuari = linesLeer.get(3);
            ConexionJDBC.adrecaIP = linesLeer.get(4);
        } else {
            //ESCRIBIR
            List<String> linesEscribir = new ArrayList<>();
            linesEscribir.add(0 + "");
            linesEscribir.add(0 + "");
            linesEscribir.add(ConexionJDBC.contrasenya);
            linesEscribir.add(ConexionJDBC.usuari);
            linesEscribir.add(ConexionJDBC.adrecaIP);
            Files.write(Paths.get(fileName), linesEscribir, StandardCharsets.UTF_8);
        }
    }

}
