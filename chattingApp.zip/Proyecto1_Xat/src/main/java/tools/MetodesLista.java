/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tools;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * 
 * 
 */
public class MetodesLista{
    /**LISTA GRUPOS
     * Una lista ordenada de GRUPOS de la DDBB.
     * @return 
     * @throws java.sql.SQLException 
     * @throws java.io.IOException 
    */
    public static ArrayList<String> listGrupos() throws SQLException, IOException{
        ArrayList<String> arrayNombreGrupo = new ArrayList<String>();
        try ( Connection conexion = tools.ConexionJDBC.conectarJDB()) {
            PreparedStatement ps = conexion.prepareStatement("SELECT nom FROM grupos");
            ps.executeQuery();
            ResultSet rs = ps.getResultSet();
            while (rs.next()) {
                arrayNombreGrupo.add(rs.getString("nom"));
            }
            rs.close();
            ps.close();
            return arrayNombreGrupo;
        } catch (SQLException ex) {
            Logger.getLogger(MetodesLista.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }
    
    /** * LISTA GRUPOS
     * Una lista ordenada de GRUPOS de la DDBB.En los que dentro de ROLES
     * idUsuario coïncida con propio
     * @param idUsuario
     * @return 
     * @throws java.sql.SQLException 
     * @throws java.io.IOException 
    */
    public static ArrayList<String> listGruposConUsuario (int idUsuario) throws SQLException, IOException {
        ArrayList<String> arrayNombreGrupo = new ArrayList<String>();
        try ( Connection conexion = tools.ConexionJDBC.conectarJDB()) {
            PreparedStatement ps = conexion.prepareStatement("SELECT nom FROM grupos g JOIN roles r ON g.id = r.idGrup WHERE r.idUsuari LIKE ?");
            ps.setInt(1, idUsuario);
            ps.executeQuery();
            ResultSet rs = ps.getResultSet();
            while (rs.next()) {
                arrayNombreGrupo.add(rs.getString("nom"));
            }
            rs.close();
            ps.close();
            Collections.sort(arrayNombreGrupo);
            return arrayNombreGrupo;
        } catch (SQLException ex) {
            Logger.getLogger(MetodesLista.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }
    
    /** * LISTA USUARIOS DE GRUPO
     * Una lista ordenada de USUARIOS de la DDBB.En los que dentro de ROLES
     * idGrupo coïncida con propio
     * @param idGrupo
     * @return 
     * @throws java.sql.SQLException 
     * @throws java.io.IOException 
    */
    public static ArrayList<String> listUsuariosConGrupo(int idGrupo) throws SQLException, IOException {
        ArrayList<String> arrayNombreGrupo = new ArrayList<String>();
        try ( Connection conexion = tools.ConexionJDBC.conectarJDB()) {
            PreparedStatement ps = conexion.prepareStatement("SELECT nom FROM usuarios u JOIN roles r ON u.id = r.idUsuari WHERE r.idGrup LIKE ?");
            ps.setInt(1, idGrupo);
            ps.executeQuery();
            ResultSet rs = ps.getResultSet();
            while (rs.next()) {
                arrayNombreGrupo.add(rs.getString("nom"));
            }
            rs.close();
            ps.close();
            Collections.sort(arrayNombreGrupo);
            return arrayNombreGrupo;
        } catch (SQLException ex) {
            Logger.getLogger(MetodesLista.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }
    
    /**LISTA USUARIOS
     * Una lista ordenada de los USUARIOS de la DDBB.
     * Lista los usuarios conectados en el servidor
     * Si existe un HashMap previo conserva las IP de las conexiones
     * @param clientesConectados
     * @return Hasmap idUsuario, y un array de valores
     */
    /*
    public HashMap<String, String> listUsuarios(String nombreUsuario, String direccionIP, HashMap<String, String> clientesConectados) {
        HashMap<String, String> llistaDeUsuaris = new HashMap<>();

        try {
            ArrayList<String> nombresUsuarios = MetodesJDBC.llistarUsuaris(); // Obtener nombres de usuarios desde la base de datos

            for (String nombre : nombresUsuarios) {
                System.out.println("Usuaris: " + nombre);
                llistaDeUsuaris.put(nombre, "Desconectado"); // Agregar usuario a la lista
            }

            // Agregar usuarios conectados junto con sus direcciones IP
            llistaDeUsuaris.putAll(clientesConectados);

        } catch (SQLException ex) {
            System.out.println("MetodesLista, metodo listUsuarios:" + ex);
        }

        return llistaDeUsuaris;
    }
    */
    /**LISTA MENSAJES
     * Una lista ordenada por emisor y fecha de aquellos mensajes con emisor
     *  y receptor iguales al cliente.
     * @return 
    */
    public String listMensajes() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    /**LISTA ARCHIVOS PUBLIC
     * Lista ordenada de aquellos ficheros con idReceptor de GRUPOS
     * @return 
    */
    public static String listPublic() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    /**LISTA ARCHIVOS PRIVATE
     * Lista ordenada de aquellos ficheros con idEmisor propio
     * y idReceptor coincida con id de USUARIOS o con id propia.
     * @return 
    */
    public static String listPrivate() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    /**LISTA ARCHIVOS PROTECTED
     * Lista ordenada de aquellos ficheros con idEmisor propio
     * y idReceptor null.
     * @return 
    */
    public static String listProtected() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}
