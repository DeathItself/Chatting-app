/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.myproject.proyecto1_xat;

import entity.MainUsuario;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Base64;

/**
 *
 * @author Soufian
 */
public class Portal {

    ArrayList<String> client_message = new ArrayList<String>();
    String clienteActual;
    Server.ClientHandler ch;

    private void setClientMessage(String mensaje) {
        this.client_message.add(mensaje);
    }

    private ArrayList<String> getClientMessage() {
        return this.client_message;
    }

    private void setClienteActual(String nombre) {
        this.clienteActual = nombre;
    }

    public String getClienteActual() {
        return this.clienteActual;

    }

    /**
     * * ENTRADA DE DATOS el DATAINPUT y DATAOUTPUT deberia gestionarlo el
     * SERVER WORKING ON...Recupera informacion recibida de CLIENTE sin
     * registrar en portal.
     *
     *
     * @param ch
     * @return
     */
    public boolean entradaDeDatos(Server.ClientHandler ch) {
        this.ch = ch;
        boolean conexionCorrecta = false;
        try {
            String datos = ch.entrada.readUTF();
            System.out.println("Recibidos estos datos = " + datos);
            String[] textoSeparado = datos.split(";");

            String operacion = textoSeparado[0];
            String nombreUsuario = textoSeparado[1];
            String entradaPassw = decodePassword(textoSeparado[2]);
            System.out.println("Operacion: " + operacion);

            switch (operacion) {
                case "INICIAR_SESION":

                    boolean inicioSesionCorrecto = usuarioRegistrado(nombreUsuario, entradaPassw);
                    System.out.println("Nombre: " + nombreUsuario);
                    System.out.println("Contraseña: " + entradaPassw);

                    if (!inicioSesionCorrecto) {
                        setClientMessage("Error al iniciar sesión. Verifique nombre y contraseña.");
                    } else {
                        System.out.println("Inicio correcta");
                        conexionCorrecta = true;
                        setClienteActual(nombreUsuario);
                    }
                    break;
                case "CREAR_USUARIO":
                    usuarioNuevo(nombreUsuario, entradaPassw);
                    System.out.println("Nombre: " + nombreUsuario);
                    System.out.println("Contraseña: " + entradaPassw);
                    break;

                default:
                    setClientMessage("No ha recibido correctamente la operacion");
                    //Terminal servidor:...
                    System.out.println("Portal, metodo entradaDeDatos: " + getClientMessage().toString());
                    //Terminal servidor.
                    break;
            }
            salidaDeDatos(ch);
        } catch (IOException e) {
            System.out.println("Error: Cliente intento Iniciar/Crear usuario" + e);
        }
        return conexionCorrecta;
    }

    public void salidaDeDatos(Server.ClientHandler ch) throws IOException {
        try {
            System.out.println("Portal, metodo salidaDeDatos: " + getClientMessage().toString());
            String mensaje = getClientMessage().toString();
            ch.salida.writeUTF(mensaje);
        } catch (IOException ioe) {
            System.out.println("No se puede enviar los datos!");
        }
    }

    /**
     * RF02: “Donar d’alta un client (Sign up)”. Entra nombre y contraseña
     * verifica si cumplen los patrones definidos, para el alta de un usuario
     * nuevo
     *
     * @param entradaNombre
     * @param entradaPassw
     */
    public void usuarioNuevo(String entradaNombre, String entradaPassw) {
        boolean errorControlNombre = false;
        boolean errorControlPassw = false;
        MainUsuario usuario = new MainUsuario(); // Crea una instancia de mainUsuario
        // Comparamos nombre al patron
        if (usuario.checkNombre(entradaNombre)) {
            // NO EXISTE un usuario con el mismo nombre que el recibido
            if (!usuario.peekUsuario()) {
                errorControlNombre = true;
            } else {
                setClientMessage("El nombre no esta disponible, introduzca otro");
            }
        } else {
            setClientMessage("El nombre introducido no cumple las indicaciones");
        }

        // Comparamos contraseña al patron
        if (usuario.checkPassw(entradaPassw)) {
            errorControlPassw = true;
        } else {
            setClientMessage("La contrasena introducida no cumple las indicaciones");
        }

        if (errorControlNombre && errorControlPassw) {
            usuario.creaUsuario();
            setClientMessage("Nuevo usuario registrado " + entradaNombre + "! Antes de chatear con otros usuarios."
                    + "\nInicie la sesion con su nuevo usuario");
        }
        //Terminal servidor:...
        System.out.println("Portal, metodo usuarioNuevo: " + getClientMessage().toString());
        System.out.println("Portal, metodo usuarioNuevo: " + usuario.getNom());
        System.out.println("Portal, metodo usuarioNuevo: " + usuario.getContrasena());
        //Terminal servidor.

    }

    /**
     * * RF03: “Donar accés a un client (Sign in)”.Mediante nombre y contraseña
     * verifica si cumplen los patrones definidos, para el usuario que ya
     * existe. Recibe un string con el nombre de usuario
     *
     * @param entradaNombre
     * @param entradaPassw
     * @return
     */
    public boolean usuarioRegistrado(String entradaNombre, String entradaPassw) {
        boolean errorControlNombre = false;
        boolean errorControlPassw = false;
        MainUsuario usuario = new MainUsuario(); // Crea una instancia de mainUsuario
        // Comparamos nombre al patron
        if (usuario.checkNombre(entradaNombre)) {
            // SI EXISTE un usuario con el mismo nombre que el recibido
            if (usuario.peekUsuario()) {
                errorControlNombre = true;
            } else {
                setClientMessage("¿Ha olvidado su nombre de usuario?");
            }
        } else {
            setClientMessage("El nombre introducido no cumple las indicaciones");
        }
        // Comparamos contraseña al patron
        if (usuario.checkPassw(entradaPassw)) {
            errorControlPassw = true;
        } else {
            setClientMessage("La contrasena introducida no cumple las indicaciones");
        }

        if (errorControlNombre && errorControlPassw) {
            String usuarioEncontrado = usuario.iniciaSesion();
            if (usuarioEncontrado != null) {
                setClienteActual(usuario.getNom());
                setClientMessage("Iniciada sesion " + entradaNombre + "! Ya puede chatear con otros usuarios.");
                return true;
            }
        }
        //Terminal servidor:...
        System.out.println("Portal, metodo usuarioRegistrado: " + getClientMessage().toString());
        System.out.println("Portal, metodo usuarioRegistrado: " + usuario.getNom());
        System.out.println("Portal, metodo usuarioRegistrado: " + usuario.getContrasena());
        //Terminal servidor.
        return false;
    }

    // Función para codificar la contraseña
    public static String encodePassword(String password) {
        return Base64.getEncoder().encodeToString(password.getBytes());
    }

    // Función para decodificar la contraseña
    public String decodePassword(String encodedPassword) {
        byte[] decodedBytes = Base64.getDecoder().decode(encodedPassword);
        return new String(decodedBytes);
    }
}
