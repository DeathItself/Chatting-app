/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */
package com.myproject.proyecto1_xat;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.EOFException;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.SocketException;
import java.util.HashMap;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Soufian
 */
public class Server extends Portal {

    public static HashMap<String, String> clientesConectados = new HashMap<>();
    public static String name;

    public static void main(String[] args) {

        int puerto = 12345;
        Portal portal = new Portal();

        try ( ServerSocket servidor = new ServerSocket(puerto)) {
            System.out.println("Servidor iniciado. Esperando conexiones...");
            //Server oServer = Server.GetInstance();
            while (true) {
                Socket cliente = servidor.accept();
                System.out.println("Cliente conectado desde " + cliente.getInetAddress());

                // Crea un hilo para manejar el cliente
                Thread clientThread = new Thread(new ClientHandler(cliente));

                clientThread.start();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static class ClientHandler implements Runnable {

        private final Socket cliente;

        DataInputStream entrada;
        DataOutputStream salida;

        public ClientHandler(Socket cliente) {
            this.cliente = cliente;
        }

        @Override
        public void run() {
            try {
                boolean continuar = true;
                while (continuar) {
                    System.out.println("INICIO RUN");
                    entrada = new DataInputStream(cliente.getInputStream());
                    salida = new DataOutputStream(cliente.getOutputStream());

                    Portal portal = new Portal();
                    Boolean acceso;
                    acceso = portal.entradaDeDatos(this);
                    salida.writeBoolean(acceso);
                    String nombreUsuario = portal.getClienteActual();
                    name = nombreUsuario;
                    String direccionIP = cliente.getInetAddress().getHostAddress();
                    // Crear un HashMap para enviar a listUsuarios

                    // El cliente tiene su propio switch
                    Room room = new Room();
                    if (acceso) {
                        clientesConectados.put(nombreUsuario, direccionIP);
                        room.Switch(this);
                        continuar = entrada.readBoolean();
                        System.out.println(continuar);
                    } else {
                        System.out.println("No has iniciado sesión");
                    }
                }
            } catch (SocketException e) {
                // Manejar la excepción aquí
                System.out.println("Se ha desconectado un cliente del socket: ");
            } catch (EOFException ex) {
                System.out.println("El cliente ha cerrado la conexion");

            } catch (IOException ex) {
                Logger.getLogger(Server.class.getName()).log(Level.SEVERE, null, ex);

            } catch (Exception e) {
                System.out.println("Excepcion " + e.toString());
            }
            System.out.println("FIN RUN");
        }
    }
}
