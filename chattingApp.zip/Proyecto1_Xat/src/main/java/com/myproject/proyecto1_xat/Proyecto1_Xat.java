/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */
package com.myproject.proyecto1_xat;

import entity.MainUsuario;
import java.net.Socket;
import java.sql.SQLException;
import java.util.ArrayList;

/**
 *
 *
 */
public class Proyecto1_Xat {

    public static void main(String[] args) throws SQLException {
        //Server objetoServer = new Server();
        /*
        System.out.println("Hello World!");
        System.out.println("El nombre ha de tener al menos 2 letras y máximo 40");
        System.out.println("La constraseña ha de tener mínimo 2 mayusculas, 2 minusculas, entre 8-12 caracteres minimo y 2 numeros y 2 caracteres especiales");
        String nombre = "alex";
        String contraseña = "AB!@ef12";
        MainUsuario usu = new MainUsuario();
        System.out.println(contraseña);
        System.out.println(nombre);
        System.out.println("");
        if (usu.checkNombre(nombre)) {
            System.out.println("Nombre correcto");
        } else {
            System.out.println("Nombre incorrecto");
        }

        if (usu.checkPassw(contraseña)) {
            System.out.println("Contraseña correcta");
        } else {
            System.out.println("Contraseña incorrecta");

        }
        */
        //Testing 
        /*String miNombreDeUsuario = "helix";
        String miContrasena = "FE!@li12";
        String miNombreDeUsuarioNuevo = "felixelgato";
        */
        
        //Testing CONEXION (en Portal)
        
        //Testing PORTAL
        
        //Portal portal = new Portal();
        
        //String entradaNombre = miNombreDeUsuario;
        //String entradaPassw = miContrasena;
        
        //portal.usuarioNuevo(entradaNombre, entradaPassw);
        //portal.usuarioRegistrado(entradaNombre, entradaPassw);
        
        //Testing ROOM
        /*Room room = new Room();
        
        String nom = miNombreDeUsuario;
        String nom2 = "telix";
        String entradaNombreGrupo = "nuevo";
        String entradaNombre = miNombreDeUsuarioNuevo;
        */
        //room.crearGrup (nom, entradaNombreGrupo);//creado
        //room.bajaGrup (nom, entradaNombreGrupo);//creado
        //room.borraGrup (nom, entradaNombreGrupo);//creado
        //room.agregaAGrup (nom2, entradaNombreGrupo);//creado
        //room.modificarUsuari(nom, entradaNombre);//creado
        //room.crearMensageNuevo (nom2,entradaNombre, "Esto es un mensaje para xat");//creado
        /*System.out.println("GRUPOS");
        ArrayList<String> listaGrupos = room.listaGruposDisponibles("helix");
        if (listaGrupos!=null){
            for (String fila : listaGrupos) {
                System.out.println(fila);
            }
        } else {
            System.out.println("Este usuario no pretenece a ningún grupo");
        }*/
        /*System.out.println("AUTO INC");
        String nombreTabla = "fitxers";
        System.out.println(tools.MetodesJDBC.proximoAutoInc(nombreTabla));*/
    }
}
