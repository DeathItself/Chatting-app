/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.myproject.proyecto1_xat;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;
import java.util.Arrays;
import java.util.Scanner;

/**
 *
 * @author Soufian
 */
public class Cliente {

    public static void main(String[] args) throws ClassNotFoundException, IOException {
        String servidor = "localhost";
        int puerto = 12345;

        try ( Socket socket = new Socket(servidor, puerto)) {
            DataInputStream entrada = new DataInputStream(socket.getInputStream());
            DataOutputStream salida = new DataOutputStream(socket.getOutputStream());

            Scanner scanner = new Scanner(System.in);

            boolean continuar = true;

            while (continuar) {
                // Menú principal
                System.out.println("Selecciona una opción:");
                System.out.println("1. Iniciar sesión");
                System.out.println("2. Crear usuario");

                int opcion = Integer.parseInt(scanner.nextLine());

                switch (opcion) {
                    case 1:
                        System.out.println("Introduce el nombre de usuario:");
                        String nombre = scanner.nextLine();
                        System.out.println("Introduce la contraseña:");
                        String passw = Portal.encodePassword(scanner.nextLine());

                        String datos = "INICIAR_SESION" + ";" + nombre + ";" + passw;

                        salida.writeUTF(datos);

                        String respuesta = entrada.readUTF();
                        System.out.println("");
                        System.out.println(respuesta);
                        System.out.println("");

                        boolean inicioSesion = entrada.readBoolean();
                        boolean continua = true;
                        if (inicioSesion) {
                            while (continua) {
                                Room.Menu();
                                int opcionSecundaria = Integer.parseInt(scanner.nextLine());
                                salida.writeInt(opcionSecundaria);

                                switch (opcionSecundaria) {
                                    case 1:
                                        System.out.println("1 para ver los clientes registrados; 2 para ver los clientes conectados");
                                        String resposta = scanner.nextLine();
                                        salida.writeUTF(resposta);
                                        if (resposta.equals("1")) {
                                            String listaUsuarios = entrada.readUTF();
                                            String[] nombres = listaUsuarios.split(",");
                                            System.out.println(Arrays.toString(nombres));
                                            System.out.println("");
                                        } else if (resposta.equals("2")) {
                                            String usuarios = entrada.readUTF();
                                            String[] nombres = usuarios.split("/");
                                            System.out.println(Arrays.toString(nombres));
                                            System.out.println("");
                                        } else {
                                            System.out.println("Opción incorrecta");
                                        }

                                        break;
                                    case 2:
                                        System.out.println("Introduce tu nombre de usuario:");
                                        String nombreUsuario = scanner.nextLine();
                                        System.out.println("Introduce el nombre del grupo");
                                        String nombreGrupo = scanner.nextLine();
                                        salida.writeUTF(nombreUsuario);
                                        salida.writeUTF(nombreGrupo);
                                        String resultadoAltaGrupo = entrada.readUTF();
                                        System.out.println(resultadoAltaGrupo);
                                        System.out.println("");
                                        break;
                                    case 3:
                                        // Dar de baja un grupo
                                        System.out.println("Introduce tu nombre de usuario");
                                        String nombreUser = scanner.nextLine();
                                        System.out.println("Introduce el nombre del grupo:");
                                        String nombreGrupoBaja = scanner.nextLine();
                                        salida.writeUTF(nombreUser);
                                        salida.writeUTF(nombreGrupoBaja);
                                        String resultadoBajaGrupo = entrada.readUTF();
                                        System.out.println(resultadoBajaGrupo);
                                        System.out.println("");
                                        break;
                                    case 4:
                                        // Administrar un grupo
                                        Room.SegundoMenu();

                                        int adminOption = scanner.nextInt();

                                        salida.writeInt(adminOption); // Envía la opción al servidor

                                        switch (adminOption) {
                                            case 1:
                                                System.out.println("Introduce el nombre del usuario a agregar:");
                                                String nomAAgregar = scanner.nextLine();
                                                System.out.println("Introduce el nombre del usuario activo:");
                                                String usuarioActivo = scanner.nextLine();
                                                System.out.println("Introduce el nombre del grupo:");
                                                String entradaNombreGrupo = scanner.nextLine();

                                                // Envía los datos al servidor
                                                salida.writeUTF(nomAAgregar);
                                                salida.writeUTF(usuarioActivo);
                                                salida.writeUTF(entradaNombreGrupo);

                                                break;
                                            case 2:
                                                System.out.println("Introduce el nombre del grupo:");
                                                String nomGrupoListar = scanner.nextLine();

                                                // Envía el nombre del grupo al servidor
                                                salida.writeUTF(nomGrupoListar);

                                                break;
                                            case 3:
                                                System.out.println("Introduce tu nombre de usuario:");
                                                String nomBaja = scanner.nextLine();
                                                System.out.println("Introduce el nombre del grupo:");
                                                String entradaNombreGrupoBaja = scanner.nextLine();

                                                // Envía los datos al servidor
                                                salida.writeUTF(nomBaja);
                                                salida.writeUTF(entradaNombreGrupoBaja);

                                                break;
                                            case 4:
                                                System.out.println("Introduce el nombre de usuario:");
                                                String nomUsuarioLista = scanner.nextLine();

                                                // Envía el nombre del usuario al servidor
                                                salida.writeUTF(nomUsuarioLista);

                                                break;
                                            default:
                                                System.out.println("Opción inválida.");
                                                break;
                                        }
                                        break;
                                    case 5:
                                        // Transmitir un fichero
                                        System.out.println("Introduce la ruta del fichero:");
                                        String rutaFichero = scanner.nextLine();
                                        salida.writeUTF(rutaFichero);
                                        String resultadoTransmitirFichero = entrada.readUTF();
                                        System.out.println(resultadoTransmitirFichero);
                                        break;
                                    case 6:
                                        // Enviar un mensaje
                                        System.out.println("Introduce el nombre del destinatario:");
                                        String destinatario = scanner.nextLine();
                                        System.out.println("Introduce el mensaje:");
                                        String mensaje = scanner.nextLine();
                                        salida.writeUTF(destinatario);
                                        salida.writeUTF(mensaje);
                                        String resultadoEnviarMensaje = entrada.readUTF();
                                        System.out.println(resultadoEnviarMensaje);
                                        break;
                                    case 7:
                                        // Leer mensajes
                                        String listaMensajes = entrada.readUTF();
                                        System.out.println(listaMensajes);
                                        break;
                                    case 8:
                                        // Enviar fichero
                                        System.out.println("Introduce la ruta del fichero:");
                                        String rutaFicheroEnviar = scanner.nextLine();
                                        salida.writeUTF(rutaFicheroEnviar);
                                        String resultadoEnviarFichero = entrada.readUTF();
                                        System.out.println(resultadoEnviarFichero);
                                        break;
                                    case 9:
                                        // Listar ficheros
                                        String listaFicheros = entrada.readUTF();
                                        System.out.println(listaFicheros);
                                        break;
                                    case 10:
                                        // Descargar ficheros
                                        System.out.println("Introduce el nombre del fichero a descargar:");
                                        String ficheroDescargar = scanner.nextLine();
                                        salida.writeUTF(ficheroDescargar);
                                        String resultadoDescargarFichero = entrada.readUTF();
                                        System.out.println(resultadoDescargarFichero);
                                        break;
                                    case 11:
                                        // Configurar servidor
                                        // ...
                                        break;
                                    case 12:
                                        // Configurar cliente
                                        // ...
                                        break;
                                    case 13:
                                        System.out.println("Cerrando sesión");
                                        continua = false;
                                        continuar = false;
                                        break;
                                    default:
                                        System.out.println("Opción inválida.");
                                        break;
                                }
                            }
                        }

                        break;

                    case 2:
                        // Crear usuario
                        System.out.println("Introduce un nombre de usuario, ha de tener al menos 2 letras y máximo 40:");
                        String nuevoNombre = scanner.nextLine();
                        System.out.println("Introduce la contraseña, ha de tener mínimo 2 mayusculas, 2 minusculas, entre 8-12 caracteres minimo, 2 números y 2 carácteres especiales:");
                        String nuevoPassw = Portal.encodePassword(scanner.nextLine());

                        String datosNuevos = "CREAR_USUARIO" + ";" + nuevoNombre + ";" + nuevoPassw;
                        salida.writeUTF(datosNuevos);

                        String resultadoCreacion = entrada.readUTF();
                        System.out.println(resultadoCreacion);
                        break;

                    default:
                        System.out.println("Opción inválida.");
                        break;
                }
                if (continuar) {
                    System.out.println("¿Desea realizar otra operación? (s/n). En caso de (n) se cerrará la sesión");
                    String continuarInput = scanner.nextLine();

                    if (!continuarInput.equalsIgnoreCase("s")) {
                        continuar = false;
                    }
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
