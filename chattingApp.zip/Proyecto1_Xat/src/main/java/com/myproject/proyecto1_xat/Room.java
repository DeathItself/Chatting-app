/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.myproject.proyecto1_xat;

import static com.myproject.proyecto1_xat.Server.clientesConectados;
import entity.MainUsuario;
import entity.MainGrupo;
import entity.MainMensaje;
import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import tools.MetodesJDBC;
import tools.MetodesLista;
import static tools.MetodesLista.listGruposConUsuario;
import static tools.MetodesLista.listGrupos;
import static tools.MetodesLista.listUsuariosConGrupo;

/**
 *
 *
 */
public class Room {

    Portal portal = new Portal();
    public final String name = Server.name;

    ArrayList<String> client_message = new ArrayList<String>();
    Server.ClientHandler ch;

    private void setClientMessage(String mensaje) {
        this.client_message.add(mensaje);
    }

    private ArrayList<String> getClientMessage() {
        return this.client_message;
    }

    public static void Menu() {
        System.out.println("MENU tienes que elegir los metodos a ejecutar");
        System.out.println("1. Listar usuarios");
        System.out.println("2. Dar de alta un grupo");
        System.out.println("3. Dar de baja un grupo");
        System.out.println("4. Administrar grupos");
        System.out.println("5. Transmitir un fichero");
        System.out.println("6. Enviar un mensaje");
        System.out.println("7. Leer mensajes");
        System.out.println("8. Enviar fichero");
        System.out.println("9. Listar ficheros");
        System.out.println("10. Descargar ficheros");
        System.out.println("11. Configurar servidor");
        System.out.println("12. Configurar cliente");
        System.out.println("13. Cerrar sesión");
    }

    public static void SegundoMenu() {
        System.out.println("Elige una opción de administración de grupo:");
        System.out.println("1. Agregar miembros");
        System.out.println("2. Listar miembros del grupo");
        System.out.println("3. Darse de baja del grupo");
        System.out.println("4. Listar grupos disponibles");
    }

    public void Switch(Server.ClientHandler ch) throws IOException, SQLException {
        this.ch = ch;
        boolean continuar = true;
        while (continuar) {

            int opcionSecundaria = ch.entrada.readInt();

            switch (opcionSecundaria) {
                case 1:
                    // Listar usuarios
                    System.out.println("Listando Usuarios");
                    String resposta = ch.entrada.readUTF();
                    if (resposta.equals("1")) {
                        ArrayList nombres = MetodesJDBC.llistarUsuaris();
                        String listaNombres = String.join(",", nombres);
                        ch.salida.writeUTF(listaNombres);
                    } else if (resposta.equals("2")) {
                        String usuarios = "";
                        for (String clave : clientesConectados.keySet()) {
                            String IP = clientesConectados.get(clave);
                            System.out.println("Nombre: " + clave + ", la IP: " + IP);
                            usuarios = usuarios + clave + ", " + IP + "/";
                        }
                        ch.salida.writeUTF(usuarios);
                    } else {
                        System.out.println("Opcion incorrecta");
                    }

                    break;
                case 2:
                    System.out.println("Dando de alta un grupo");
                    String nombre = ch.entrada.readUTF();
                    String nombreGrupo = ch.entrada.readUTF();
                    crearGrup(nombre, nombreGrupo);

                    break;
                case 3:
                    System.out.println("Dando de baja un grupo");
                    String nombreClient = ch.entrada.readUTF();
                    String nombreGrupoAdmin = ch.entrada.readUTF();
                    borraGrup(nombreClient, nombreGrupoAdmin);
                    break;
                case 4:
                    System.out.println("Administrando Grupos");

                    int adminOption = ch.entrada.readInt(); // Recibe la opción del cliente

                    switch (adminOption) {
                        case 1:
                            String nomAAgregar = ch.entrada.readUTF();
                            String usuarioActivo = ch.entrada.readUTF();
                            String entradaNombreGrupo = ch.entrada.readUTF();
                            agregaAGrup(nomAAgregar, usuarioActivo, entradaNombreGrupo);
                            break;

                        case 2:
                            String nomGrupoListar = ch.entrada.readUTF();
                            ArrayList<String> listaUsuarios = listUsuariosDisponiblesPorGrupo(nomGrupoListar);

                            // Enviar la lista de usuarios al cliente
                            ch.salida.writeInt(listaUsuarios.size());
                            for (String usuario : listaUsuarios) {
                                ch.salida.writeUTF(usuario);
                            }
                            break;

                        case 3:
                            String nomBaja = ch.entrada.readUTF();
                            String entradaNombreGrupoBaja = ch.entrada.readUTF();
                            bajaGrup(nomBaja, entradaNombreGrupoBaja);
                            break;

                        case 4:
                            String nomUsuarioLista = ch.entrada.readUTF();
                            ArrayList<String> listaGrupos = listaGruposDisponibles(nomUsuarioLista);

                            // Enviar la lista de grupos al cliente
                            ch.salida.writeInt(listaGrupos.size());
                            for (String grupo : listaGrupos) {
                                ch.salida.writeUTF(grupo);
                            }
                            break;

                        default:
                            System.out.println("Opción inválida.");
                            break;
                    }
                    break;
                case 5:
                    System.out.println("Transmitiendo fichero");
                    /*
                                            String rutaFichero = entrada.readUTF();
                                            String resultadoTransmitirFichero = transmitirFichero(rutaFichero);
                                            salida.writeUTF(resultadoTransmitirFichero);*/
                    break;
                case 6:
                    System.out.println("Enviando Mensaje");
                    /*
                                            String destinatario = entrada.readUTF();
                                            String mensaje = entrada.readUTF();
                                            String resultadoEnviarMensaje = enviarMensaje(destinatario, mensaje);
                                            salida.writeUTF(resultadoEnviarMensaje);*/
                    break;
                case 7:
                    System.out.println("Leyendo Mensaje");
                    /*
                                            String listaMensajes = leerMensajes();
                                            salida.writeUTF(listaMensajes);*/
                    break;
                case 8:
                    System.out.println("Enviando fichero");
                    /*
                                            String rutaFicheroEnviar = entrada.readUTF();
                                            String resultadoEnviarFichero = enviarFichero(rutaFicheroEnviar);
                                            salida.writeUTF(resultadoEnviarFichero);*/
                    break;
                case 9:
                    System.out.println("Listando ficheros");
                    /*
                                            String listaFicheros = listarFicheros();
                                            salida.writeUTF(listaFicheros);*/
                    break;
                case 10:
                    System.out.println("Descargando Fichero");
                    /*
                                            String ficheroDescargar = entrada.readUTF();
                                            String resultadoDescargarFichero = descargarFichero(ficheroDescargar);
                                            salida.writeUTF(resultadoDescargarFichero);*/
                    break;
                case 11:
                    System.out.println("Configurando servidor");
                    // Configurar servidor
                    // ...
                    break;
                case 12:
                    System.out.println("Configurando cliente");
                    // Configurar cliente
                    // ...
                    break;
                case 13:
                    System.out.println("Cerrando sesión");
                    continuar = false;
                    ch.salida.writeBoolean(continuar);
                    Server.clientesConectados.remove(name);
                    System.out.println(name);
                    break;
                default:
                    ch.salida.writeUTF("Opción inválida.");
                    break;
            }
        }
    }

    //USUARIOS
    /**
     * RF05: “Llistar usuaris”.
     *
     */
    //---
    //GRUPO
    /**
     * RF06: “Donar d’alta un grup”.
     *
     * @param nom
     * @param entradaNombreGrupo
     */
    public void crearGrup(String nom, String entradaNombreGrupo) {
        MainGrupo grupo = new MainGrupo();
        if (grupo.checkNombreGrupo(entradaNombreGrupo)) {
            if (!grupo.peekGrupo()) {
                grupo.creaGrupo(nom);
                setClientMessage("El grupo se ha creado correctamente.");
            }
        } else {
            setClientMessage("El nombre del grupo a crear no cumple con las indicaciones:"
                    + "\n· El nombre del grupo solo puede contener letras."
                    + "\n· El nombre del grupo no puede estar repetido.");
        }
        // Enviar respuesta al cliente
        try {
            ch.salida.writeUTF(getClientMessage().toString());
        } catch (IOException e) {
            e.printStackTrace();
        }
        //Terminal servidor:...
        System.out.println("Room, metodo crearGrup: " + getClientMessage().toString());
        //Terminal servidor.
    }

    /**
     * RF07: “Donar de baixa un grup”. BORRAR EL GRUPO Y LOS ROLES SOLO
     * DISPONBLE PARA OWNER
     *
     * @param nom
     * @param entradaNombreGrupo
     */
    public void borraGrup(String nom, String entradaNombreGrupo) {
        MainGrupo grupo = new MainGrupo();
        if (grupo.checkNombreGrupo(entradaNombreGrupo)) {
            if (grupo.peekGrupo()) {
                grupo.borraGrupo(nom);
                setClientMessage("El grupo se ha eliminado correctamente.");
            }
        } else {
            setClientMessage("El nombre del grupo a eliminar no existe");
        }
        try {
            ch.salida.writeUTF(getClientMessage().toString());
        } catch (IOException e) {
            e.printStackTrace();
        }
        //Terminal servidor:...
        System.out.println("Room, metodo borraGrup: " + getClientMessage().toString());
        //Terminal servidor.
    }

    /**
     * RF08: “Administrar un grup”. AGREGAR MIEMBROS AL GRUPO SOLO DISPONBLE
     * PARA OWNER
     *
     * @param nomAAgregar
     * @param usuarioActivo
     * @param entradaNombreGrupo
     * @throws java.io.IOException
     */
    public void agregaAGrup(String nomAAgregar, String usuarioActivo, String entradaNombreGrupo) throws IOException {
        MainGrupo grupo = new MainGrupo();
        if (grupo.checkNombreGrupo(entradaNombreGrupo)) {
            if (grupo.peekGrupo()) {
                grupo.AgregaUsuarioAGrupo(nomAAgregar, usuarioActivo);
                setClientMessage("Se ha añadido un cliente correctamente al grupo.");
            }
        } else {
            setClientMessage("El nombre del usuario a añadir no cumple indicaciones:"
                    + "\n· El nombre del grupo solo puede contener letras."
                    + "\n· El nombre del grupo no puede estar repetido.");
        }
        try {
            ch.salida.writeUTF(getClientMessage().toString());
        } catch (IOException e) {
            e.printStackTrace();
        }
        //Terminal servidor:...
        System.out.println("Room, metodo crearGrup: " + getClientMessage().toString());
        //Terminal servidor.
    }

    /**
     * RF08: “Administrar un grup”. LISTAR MIEMBROS DEL GRUPO
     *
     * @param nomGrupo
     * @return
     * @throws java.io.IOException
     */
    public ArrayList<String> listUsuariosDisponiblesPorGrupo(String nomGrupo) throws IOException {
        MainGrupo grupo = new MainGrupo();
        if (grupo.checkNombreGrupo(nomGrupo)) {
            if (grupo.peekGrupo()) {
                try {
                    String[] dataGrupo = tools.MetodesJDBC.consultarIdNom(0, nomGrupo, "grupos");
                    if (dataGrupo[0] != null) {
                        int idGrupo = Integer.parseInt(dataGrupo[0]);
                        //Metodos Lista
                        return listUsuariosConGrupo(idGrupo);
                    } else {
                        ArrayList<String> listaVacia = new ArrayList<String>();
                        return listaVacia;
                    }
                } catch (SQLException ex) {
                    Logger.getLogger(MetodesLista.class.getName()).log(Level.SEVERE, null, ex);
                }
            } else {
                setClientMessage("El grupo no existe");
            }
        }
        try {
            ch.salida.writeUTF(getClientMessage().toString());
        } catch (IOException e) {
            e.printStackTrace();
        }
        //Terminal servidor:...
        System.out.println("Room, metodo listUsuariosDisponiblesPorGrupo: " + getClientMessage().toString());
        //Terminal servidor.
        return null;
    }

    /**
     * RF08: “Administrar un grup”. DARSE DE BAJA DEL GRUPO (funcion extra)
     *
     * @param nom
     * @param entradaNombreGrupo
     */
    public void bajaGrup(String nom, String entradaNombreGrupo) {
        MainGrupo grupo = new MainGrupo();
        if (grupo.checkNombreGrupo(entradaNombreGrupo)) {
            if (grupo.peekGrupo()) {
                grupo.salirGrupo(nom);
                setClientMessage("Has sido eliminado correctamente del grupo.");
            }
        } else {
            setClientMessage("El nombre del grupo a dar de baja no existe");
        }
        try {
            ch.salida.writeUTF(getClientMessage().toString());
        } catch (IOException e) {
            e.printStackTrace();
        }
        //Terminal servidor:...
        System.out.println("Room, metodo bajaGrup: " + getClientMessage().toString());
        //Terminal servidor.
    }

    /**
     * LISTA GRUPOS DISPONIBLES LISTA DE GRUPOS AL QUE EL USUARIO PERTENECE
     * (funcion extra)
     *
     * @param nom
     * @return
     * @throws java.sql.SQLException
     * @throws java.io.IOException
     */
    public ArrayList<String> listaGruposDisponibles(String nom) throws SQLException, IOException {
        if (nom != null) {
            try {
                String[] idNomUsuario = tools.MetodesJDBC.consultarIdNom(0, nom, "usuarios");
                if (idNomUsuario[0] != null) {
                    int idUsuario = Integer.parseInt(idNomUsuario[0]);
                    //Metodos Lista
                    return listGruposConUsuario(idUsuario);
                } else {
                    setClientMessage("El usuario no pertenece al grupo");
                    return null;
                }
            } catch (SQLException ex) {
                Logger.getLogger(MetodesLista.class.getName()).log(Level.SEVERE, null, ex);
            }
        } else {
            return listGrupos();
        }
        try {
            ch.salida.writeUTF(getClientMessage().toString());
        } catch (IOException e) {
            e.printStackTrace();
        }
        setClientMessage("Error DDBB al listar Grupos");
        //Terminal servidor:...
        System.out.println("Room, metodo listaGruposDisponibles: " + getClientMessage().toString());
        //Terminal servidor.
        return null;
    }

    //ARCHIVO 1/4
    /**
     * RF09: “Transmissió d’un fitxer”.
     *
     */
    // - - -
    //MENSAJE
    /**
     * 10.ALTA MENSAJE
     *
     * @param entradaEmissor
     * @param entradaReceptor
     * @param entradaContenidoMensaje
     */
    public void crearMensageNuevo(int entradaEmissor, int entradaReceptor, String entradaContenidoMensaje) {
        MainMensaje mensaje = new MainMensaje();
        if (mensaje.checkDirecciones(entradaEmissor, entradaReceptor, entradaContenidoMensaje)) {
            mensaje.creaMensaje();
        } else {
            setClientMessage("Algun dato de la direccion no cumple las indicaciones");
        }
        //Terminal servidor:...
        System.out.println("Room, metodo crearMensageNuevo: " + getClientMessage().toString());
        //Terminal servidor.
    }

    /**
     * RF11: ”Llegir missatges”.
     *
     */
    //ARCHIVO 2/4
    /**
     * RF12: “Enviar fitxer al servidor”.
     *
     */
    /**
     * RF13: “Llistat fitxers”.
     *
     */
    /**
     * RF14: “Descarregar fitxer”.
     *
     */
    //CONFIGURACION
    /**
     * RF15: “Configuració servidor”. Este se encuentra en la conexion del
     * servidor mientras no tengamos un cliente administrador
     */
    /**
     * RF16: “Configuració client”. 1/2 part
     *
     * @param nom
     * @param entradaNombre
     */
    public void modificarUsuari(String nom, String entradaNombre) {
        MainUsuario usuario = new MainUsuario();
        if (usuario.checkNombre(entradaNombre)) {
            if (usuario.checkNombre(nom)) {
                usuario.modificaUsuario(entradaNombre);
                //Este se encuentra en el cliente
                //Despues de modificar el nombre el Cliente debe recrear el cliente.conf
            } else {
                setClientMessage("El nombre nuevo no cumple con las indicaciones");
            }
        }
        //Terminal servidor:...
        System.out.println("Room, metodo modificarUsuari: " + getClientMessage().toString());
        //Terminal servidor.
    }

    public int ConsultarNombreId() throws SQLException, IOException {
        System.out.println(name);
        String id = MetodesJDBC.consultarIdNom(0, name, "usuarios")[0];
        int idUser = Integer.parseInt(id);
        return idUser;
    }
}
