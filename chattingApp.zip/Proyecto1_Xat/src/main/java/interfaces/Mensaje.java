/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package interfaces;

/**
 *
 * 
 */
public interface Mensaje {
    /**CREAR MENSAJE
     * Insertar un nuevo registro en MENSAJE
     */
    public void creaMensaje();
    /**BORRAR MENSAJE
     * Mediante un id borrar el registro de la DDBB
    */
    public void borrarMensaje();
    /**VISUALIZAR MENSAJE
     * Mediante un id mostrar el contenido del mensaje en un array
    */
    public void pickMensaje();
}