/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package interfaces;

/**
 *
 * @author Ricard
 */
public interface Roles {
    /** * CREAR NUEVO ROL.Dentro de la DDBB inserta un nuevo registro en ROLES.
     * @param idUsuario
     * @param permiso
    */
    public void nuevoRol(int idUsuario,String permiso);
    /**BORRA UN ROL.
     * En la DDBB elimina un rol segun valor recibido.
    */
    public void eliminaRol();
    /**HEREDA UN ROL.
     * En la DDBB modifica permiso segun datos recibidos.
    */
    public void herenciaRol();
    /**ELIMINA UN ROL EN CASCADA.
     *En la DDBB elimina todos los roles segun grupo recibido.
    */
    public boolean eliminaRolCascada();
}
