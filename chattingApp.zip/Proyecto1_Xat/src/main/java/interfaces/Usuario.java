/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package interfaces;

/**
 *
 * 
 */
public interface Usuario {
    /**VALIDAR nombre de USUARIO con expresiones regulare
     * @param nombre
     * @return boolean
    */
    public boolean checkNombre(String nombre);
    /**VALIDAR contraseña de USUARIO con expresiones regulare
     * @param passw
     * @return boolean
    */
    public boolean checkPassw(String passw);
    /**CREAR USUARIO
     * Insertar un nuevo registro en USUARIOS
     * Crea un fichero de configuracion y envialo al cliente
    */
    public void creaUsuario();
    /**MODIFICAR NOMBRE
     * Recibe un fichero de configuracion
     * Modifica el nombre de USUARIOS
     * Crea un fichero de configuracion y envialo al cliente
    */
    public void modificaUsuario(String nomMod);
    /**VALIDA si USUARIO ya existe
     * Consulta la DDBB si el nombre de usuario introducido esta registrado
     * @return 
    */
    public boolean peekUsuario();
    /**INICIAR SESION DE USUARIO PERVIAMENTE REGISTRADO
     * Consulta si el nombre de usuario y su contraseña corresponden
     * al mismo registro de la DDBB
     */
    public String iniciaSesion();
}

