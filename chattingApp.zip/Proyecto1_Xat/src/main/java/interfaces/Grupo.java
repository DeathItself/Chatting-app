/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package interfaces;

/**
 *
 * 
 */
public interface Grupo {
    /**CREAR NUEVO GRUPO.
     * Dentro de la DDBB inserta un nuevo registro en GRUPO
     * seguido de insertar otro en ROLES con el tipo OWNER.
    */
    public void creaGrupo(String nombreUsuario);
    /**ELIMINAR GRUPO (solo aquellos con permiso de OWNER)
     * En la DDBB dentro de ROLES borra cada uno con los que coincida idGroup.
     * Elimina la referencia en GRUPOS al acabar
    */
    public void borraGrupo(String nombreUsuario);
    /**BAJA DE GRUPO.
     * Borra la referencia de tu id en ROL dentro de la base de datos.
     * En caso que seas el OWNER del GRUPO el permiso tipo OWNER 
     * queda traspasado segun antiguedad y ordeen abecedario.
     * Nota. en caso de existir ADMINISTRADOR estos tienen prioridad.
     * Nota. en caso de ser el ultimo integrante del GRUPO borrar referencia.
    */
    public void salirGrupo(String nombreUsuario);
    /**VALIDA si el GRUPO ya existe
     * Consulta la DDBB si el nombre de grupo introducido esta registrado
     * @return 
    */
    public boolean peekGrupo();
}
