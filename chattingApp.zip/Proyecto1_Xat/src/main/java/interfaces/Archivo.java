/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package interfaces;

/**
 *
 * 
 */
public interface Archivo {
    /**CREAR NUEVO ARCHIVO.
     * Dentro de la DDBB inserta un nuevo registro en FITXERS.
     * Asignar null en atributo Receptor.
     * "El fichero se considera protected" solo visible para el propietario.
    */
    public void creaArchivo();
    /**ENVIA UN ARCHIVO.
     * En DDBB FITXERS modifica Receptor con la id del remitente CLIENTE/GRUPO.
     * Si se envia a un cliente "el fichero se considera private"
     * Si se envia a un grupo "el fichero se considera public"
    */
    public void sendArchivo();
    /**BORRA UN ARCHIVO.
     * En DDBB FITXERS elimina el registro.
     * Solo cuando la propiedad del fichero coincida con el usuario.
     * Borra el fichero de la carpeta en el servidor.
    */
    public void borraArchivo();
}
