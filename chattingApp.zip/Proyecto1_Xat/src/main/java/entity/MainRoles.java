/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package entity;

import interfaces.Roles;
import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * 
 */
public class MainRoles implements Roles{
    private int idUsuario = 0;
    private int idGrupo = 0;
    
    public int getIdUsuario() {
        return idUsuario;
    }
    public void setIdUsuario(int idUsuario) {
        this.idUsuario = idUsuario;
    }
    public int getIdGrupo() {
        return idGrupo;
    }
    public void setIdGrupo(int idGrupo) {
        this.idGrupo = idGrupo;
    }
    
    /**CREAR NUEVO ROL.Dentro de la DDBB inserta un nuevo registro en ROLES.
     * @param nombreUsuario
     * @param nombreGrupo
     * @return 
     * @throws java.sql.SQLException
     * @throws java.io.IOException
    */
    public boolean checkIdRol(String nombreUsuario, String nombreGrupo) throws SQLException, IOException{
        String idEnString;
        int id = 0;
        if(nombreUsuario != null){
            if (tools.MetodesJDBC.consultarIdNom(id,nombreUsuario,"usuarios") != null) {
                idEnString = tools.MetodesJDBC.consultarIdNom(id,nombreUsuario,"usuarios")[0];
                setIdUsuario(Integer.parseInt(idEnString));
            }
        }
        idEnString = "";
        if(nombreGrupo != null){
            if (tools.MetodesJDBC.consultarIdNom(id,nombreGrupo,"grupos") != null) {
                idEnString = tools.MetodesJDBC.consultarIdNom(id,nombreGrupo,"grupos")[0];
                setIdGrupo(Integer.parseInt(idEnString));
            }
        }
        return (getIdUsuario() != 0 || getIdGrupo() != 0);
    }
    
    public boolean checkPermisoRol() throws SQLException{
        boolean bo = false;
        try {
            if(tools.MetodesJDBC.consultaRol(getIdUsuario(), getIdGrupo())[1].equals("OWNER")){
                bo = true;
            }
        } catch (SQLException | IOException | NullPointerException ex) {
            Logger.getLogger(MainRoles.class.getName()).log(Level.SEVERE, null, ex);
        }
        return bo;
    }
    
    /**INSERTA UN ROL.
     * Crea un rol del tipo recibido.
    */
    @Override
    public void nuevoRol(int idUsuario ,String permiso) {
        try {
            tools.MetodesJDBC.insertarRol(idUsuario, getIdGrupo(), permiso);
        } catch (SQLException | IOException ex) {
            Logger.getLogger(MainUsuario.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    /**BORRA UN ROL.
     * En la DDBB elimina un rol segun valor recibido.
    */
    @Override
    public void eliminaRol() {
        try {
            tools.MetodesJDBC.eliminaRol(getIdUsuario(), getIdGrupo());
        } catch (SQLException | IOException ex) {
            Logger.getLogger(MainUsuario.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    /**HEREDA UN ROL.
     * En la DDBB modifica permiso segun datos recibidos.
     * Elimina el Grupo si no encuentra un usuario para heredar
    */
    @Override
    public void herenciaRol() {
        try {
            String[] usuarioRol = tools.MetodesJDBC.consultaRol(getIdUsuario(), getIdGrupo());
            String permiso = usuarioRol[1];
            if (permiso.equals("OWNER")) {
                ArrayList<String[]> listaRolesOrdenada = new ArrayList<String[]>();
                //roles ordenados por grupo
                listaRolesOrdenada = tools.MetodesJDBC.listaOrdenadaRoles(getIdGrupo());
                boolean checkSiguenteMiembro = true;
                int idHeredero = 0;
                for (String[] fila : listaRolesOrdenada) {
                    System.out.println(fila[0]+fila[1]+fila[2]);
                    if (!fila[1].equals("OWNER") && checkSiguenteMiembro) {
                        //Encontrar Heredero para el GRUPO
                        checkSiguenteMiembro = false;
                        idHeredero = Integer.parseInt(fila[0]);
                    }
                }
                if (!checkSiguenteMiembro) {
                    //Si encuentra Heredero para el GRUPO elimina rol y modifica heredero
                    tools.MetodesJDBC.eliminaRol(getIdUsuario(), getIdGrupo());
                    tools.MetodesJDBC.modificarRol(idHeredero, "OWNER");
                } else {
                    //En caso contrario elimina rol y elimina GRUPO
                    tools.MetodesJDBC.eliminaRol(getIdUsuario(), getIdGrupo());
                    tools.MetodesJDBC.eliminaGrupo(getIdGrupo());
                }
            } else {
                tools.MetodesJDBC.eliminaRol(getIdUsuario(), getIdGrupo());
            }
        } catch (SQLException | IOException ex) {
            Logger.getLogger(MainUsuario.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    /**ELIMINA ROLES EN CASCADA.
     * Elimina todos los roles de un grupo.
     * @return 
    */
    @Override
    public boolean eliminaRolCascada() {
        try {
            String[] usuarioRol = tools.MetodesJDBC.consultaRol(getIdUsuario(), getIdGrupo());
            String permiso = usuarioRol[1];
            if (permiso.equals("Propietario")) {
                tools.MetodesJDBC.eliminaRolesCascada(getIdGrupo());
                return true;
            }
        } catch (SQLException | IOException ex) {
            Logger.getLogger(MainUsuario.class.getName()).log(Level.SEVERE, null, ex);
        }
        return false;
    }
}
