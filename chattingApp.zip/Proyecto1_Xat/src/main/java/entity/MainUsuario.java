/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package entity;

import interfaces.Usuario;
import java.io.IOException;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 *
 */
public class MainUsuario implements Usuario {

    public String nombre = null;
    public String passw = null;

    public void setNom(String valor) {
        this.nombre = valor;
    }

    public String getNom() {
        return this.nombre;
    }

    public void setContrasena(String valor) {
        this.passw = valor;
    }

    public String getContrasena() {
        return this.passw;
    }

    @Override
    public String toString() {
        return "MainUsuario{" + "nombre=" + getNom() + ", passw=" + getContrasena() + '}';
    }

    /**
     * VALIDAR nombre de USUARIO con expresiones regulare
     *
     * @param nombre
     * @return boolean
     */
    @Override
    public boolean checkNombre(String nombre) {
        String nom = nombre;
        //[a-z]                         //Un conjunto de letras en minuscula
        //{2,40}                        //Entre dos y cuarenta caracteres
        String regex = "[a-z]{2,40}";
        if (nom.matches(regex)) {
            setNom(nom);
        }
        return nom.matches(regex);
    }

    /**
     * VALIDAR contraseña de USUARIO con expresiones regulare
     *
     * @param passw
     * @return boolean
     */
    @Override
    public boolean checkPassw(String passw) {
        String contraseña = passw;
        //^(?=(?:[^A-Z]*[A-Z]){2,12})   //Busca un minimo de dos letras en mayuscula
        //(?=(?:[^a-z]*[a-z]){2,12})    //Busca un minimo de dos letras en minuscula
        //(?=(?:\\D*\\d){2,12})         //Busca un minimo de dos numeros
        //(?=(?:[^\\W_]*[\\W_]){2,12})  //Busca un minimo de dos caracteres especiales
        //[\\w\\W]{8,12}$               //Busca cualquier caracter entre 8 i 12
        String regex = "^(?=(?:[^A-Z]*[A-Z]){2,12})(?=(?:[^a-z]*[a-z]){2,12})(?=(?:\\D*\\d){2,12})(?=(?:[^\\W_]*[\\W_]){2,12})[\\w\\W]{8,12}$";
        if (passw.matches(regex)) {
            setContrasena(passw);
        }
        return contraseña.matches(regex);
    }

    /**
     * MODIFICAR NOMBRE Recibe un fichero de configuracion Modifica el nombre de
     * USUARIOS Crea un fichero de configuracion y envialo al cliente
     */
    @Override
    public void creaUsuario() {
        try {
            String user = getNom();
            String pass = getContrasena();
            tools.MetodesJDBC.insertarUsuari(user, pass);
        } catch (SQLException | IOException ex) {
            Logger.getLogger(MainUsuario.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    /**
     * MODIFICAR NOMBRE Recibe un fichero de configuracion Modifica el nombre de
     * USUARIOS Crea un fichero de configuracion y envialo al cliente
     *
     * @param nomMod
     */
    @Override
    public void modificaUsuario(String nomMod) {
        try {
            tools.MetodesJDBC.modificarUsuari(getNom(), nomMod);
        } catch (SQLException | IOException ex) {
            Logger.getLogger(MainUsuario.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    /**
     * VALIDA si USUARIO ya existe Consulta la DDBB si el nombre de usuario
     * introducido esta registrado
     *
     * @return
     */
    @Override
    public boolean peekUsuario() {
        String nom = getNom();
        boolean comprobar = false;
        String nombreDB = "";
        String grupoDB = "";
        try {
            int id = 0;
            if (tools.MetodesJDBC.consultarIdNom(id, nom, "usuarios") != null) {
                nombreDB = tools.MetodesJDBC.consultarIdNom(id, nom, "usuarios")[1];
            }
            if (tools.MetodesJDBC.consultarIdNom(id, nom, "grupos") != null) {
                grupoDB = tools.MetodesJDBC.consultarIdNom(id, nom, "grupos")[1];
            }
            if (nom.equals(nombreDB) || nom.equals(grupoDB)) {
                comprobar = true;
            }
        } catch (SQLException | IOException ex) {
            Logger.getLogger(MainUsuario.class.getName()).log(Level.SEVERE, null, ex);
        }
        return comprobar;
    }

    /**
     * INICIAR SESION DE USUARIO PERVIAMENTE REGISTRADO Consulta si el nombre de
     * usuario y su contraseña corresponden al mismo registro de la DDBB
     *
     * @return
     */
    @Override
    public String iniciaSesion() {
        String nom = getNom();
        String contrasena = getContrasena();
        try {
            String usuarioEncontrado = tools.MetodesJDBC.consultarUsuari(nom, contrasena);
            if (usuarioEncontrado != null) {
                return usuarioEncontrado;
            }
        } catch (SQLException | IOException ex) {
            Logger.getLogger(MainUsuario.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    }
}
