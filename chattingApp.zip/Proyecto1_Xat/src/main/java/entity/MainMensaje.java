/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package entity;

import interfaces.Mensaje;
import java.io.IOException;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * 
 */
public class MainMensaje implements Mensaje {
    private int from;
    private int to;
    private String contenido;
    
    public int getFrom() {
        return from;
    }
    public void setFrom(int from) {
        this.from = from;
    }
    public int getTo() {
        return to;
    }
    public void setTo(int to) {
        this.to = to;
    }
    public String getContenido() {
        return contenido;
    }
    public void setContenido(String contenido) {
        this.contenido = contenido;
    }
    /**VALIDAR DIRECCIONES
     * Valida los nombres con expresiones regulares y si existen en la DDBB
     * @param from
     * @param to
     * @param contenido
     * @return boolean
    */
    public boolean checkDirecciones(int from, int to, String contenido) {
        ///\\w/g{2,40}  //Comprueba que el contenido del mensaje sea de dos a cuarenta caracteres alfanumericos
        String regex = "/\\w/g{2,40}";
        boolean bo = false;
        if (from!=0 && to!=0) {
            setFrom(from);
            setTo(to);
            if(contenido.matches(regex) == true) {
                setContenido(contenido);
                return true;
            }
        }
        return false;
    }
    
    public boolean peekUsuario() {
        int idFrom = getFrom();
        int idTo = getTo();
        boolean comprobar = false;
        String nombreFrom = null;
        String nombreTo = null;
        try {
            String nombre = null;
            if(tools.MetodesJDBC.consultarIdNom(idFrom,nombre,"usuarios") != null){
                nombreFrom = tools.MetodesJDBC.consultarIdNom(idFrom,nombre,"usuarios")[0];
            } else if (tools.MetodesJDBC.consultarIdNom(idFrom,nombre,"grupos") != null){
                nombreFrom = tools.MetodesJDBC.consultarIdNom(idFrom,nombre,"grupos")[0];
            }
            if(tools.MetodesJDBC.consultarIdNom(idTo,nombre,"usuarios") != null){
                nombreTo = tools.MetodesJDBC.consultarIdNom(idTo,nombre,"usuarios")[0];
            } else if (tools.MetodesJDBC.consultarIdNom(idTo,nombre,"grupos") != null){
                nombreTo = tools.MetodesJDBC.consultarIdNom(idTo,nombre,"grupos")[0];
            }
            if (nombreFrom!=null && nombreTo!=null){
                comprobar =  true;
            }
        } catch (SQLException | IOException ex) {
            Logger.getLogger(MainUsuario.class.getName()).log(Level.SEVERE, null, ex);
        }
        return comprobar;
    }
    
    /**CREAR MENSAJE
     * Insertar un nuevo registro en MENSAJE
     */
    @Override
    public void creaMensaje() {
        try {
            tools.MetodesJDBC.insertarMensaje(getFrom(),getTo(),getContenido());
        } catch (SQLException | IOException ex) {
            Logger.getLogger(MainUsuario.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    /**BORRAR MENSAJE
     * Mediante un id borrar el registro de la DDBB
    */
    @Override
    public void borrarMensaje() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    /**VISUALIZAR MENSAJE
     * Mediante un id mostrar el contenido del mensaje en un array
    */
    @Override
    public void pickMensaje() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}
