/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package entity;
import interfaces.Grupo;
import java.io.IOException;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * 
 */
public class MainGrupo implements Grupo {
    private String nombreGrupo;
    
    public void setNombreGrupo(String nombre){
        this.nombreGrupo = nombre;
    }
    public String getNombreGrupo(){
        return this.nombreGrupo;
    }
    /**VALIDAR nombre de GRUPO con expresiones regulares
     * Y consulta con peekGrupo si ya existe
     * @param nombre
     * @return boolean
    */
    public boolean checkNombreGrupo(String nombre) {
        //[a-z]                         //Un conjunto de letras en minuscula
        //{2,10}                        //Entre dos y diez caracteres
        String regex = "[a-z]{2,10}";
        if(nombre.matches(regex) == true) {
            setNombreGrupo(nombre);
            return true;
        }
        return false;
    }
    /** * AGREAGA USUARIO AL GRUPO.Dentro de la DDBB inserta un nuevo registro en ROLES 
     * @param nombreUsuario
     * @param usuarioActivo
     * @throws java.io.IOException
    */
    public void AgregaUsuarioAGrupo(String nombreUsuario, String usuarioActivo) throws IOException{
        MainRoles rol = new MainRoles();
        try {
            if(rol.checkIdRol(usuarioActivo, getNombreGrupo())){
                if(rol.checkPermisoRol()){
                    int idUsuario = 0;
                    String StringUsuario = tools.MetodesJDBC.consultarIdNom(idUsuario, nombreUsuario,"usuarios")[0];
                    idUsuario = (Integer.parseInt(StringUsuario));
                    rol.nuevoRol(idUsuario,"MIEMBRO");
                }
            }
        } catch (SQLException ex) {
            Logger.getLogger(MainGrupo.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    /**CREAR NUEVO GRUPO.
     * Dentro de la DDBB inserta un nuevo registro en GRUPO 
     * seguido de insertar otro en ROLES con el tipo OWNER.
     * @param nombreUsuario
    */
    @Override
    public void creaGrupo(String nombreUsuario) {
        MainRoles rol = new MainRoles();
        try {
            tools.MetodesJDBC.insertarGrup(getNombreGrupo());
            if(rol.checkIdRol(nombreUsuario, getNombreGrupo())){
                int idUsuario = 0;
                String StringUsuario = tools.MetodesJDBC.consultarIdNom(idUsuario, nombreUsuario,"usuarios")[0];
                idUsuario = (Integer.parseInt(StringUsuario));
                rol.nuevoRol(idUsuario,"Propietario");
            }
        } catch (SQLException | IOException ex) {
            Logger.getLogger(MainGrupo.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    /** * ELIMINAR GRUPO (solo aquellos con permiso de OWNER)
     * En la DDBB dentro de ROLES borra cada uno con los que coincida idGroup.Elimina la referencia en GRUPOS al acabar
     * @param nombreUsuario
    */
    @Override
    public void borraGrupo(String nombreUsuario) {
        MainRoles rol = new MainRoles();
        int id = 0;
        try {
            if(rol.checkIdRol(nombreUsuario, getNombreGrupo())){
                //eliminaRolCascada solo es true si puede eliminar los roles siendo OWNER del grupo
                if(rol.eliminaRolCascada()){
                    String[] respuestaGrupo = tools.MetodesJDBC.consultarIdNom(id,getNombreGrupo(), "Grupos");
                    int idGrupo = Integer.parseInt(respuestaGrupo[0]);
                    tools.MetodesJDBC.eliminaGrupo(idGrupo);
                }
            }
        } catch (SQLException | IOException ex) {
            Logger.getLogger(MainGrupo.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    /**BAJA DE GRUPO.
     * Borra la referencia de tu id en ROL dentro de la base de datos.
     * En caso que seas el OWNER del GRUPO Borra la referencia de tu id en ROL 
     * dentro de la base de datos.el permiEn caso que seas el OWNER del GRUPO 
     * el permiso tipo OWNER queda traspasado segun antiguedad y ordeen abecedario.
     * Nota. en caso de existir ADMINISTRADOR estos tienen prioridad.
     * Nota. en caso de ser el ultimo integrante del GRUPO borrar referencia.
     * @param nombreUsuario
    */
    @Override
    public void salirGrupo(String nombreUsuario) {
        MainRoles rol = new MainRoles();
        try {
            if(rol.checkIdRol(nombreUsuario, getNombreGrupo())){
                rol.herenciaRol();
            }
        } catch (SQLException | IOException ex) {
            Logger.getLogger(MainUsuario.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @Override
    public boolean peekGrupo() {
        String nom = getNombreGrupo();
        boolean comprobar = false;
        String nombreDB = "";
        String grupoDB = "";
        int id = 0;
        try {
            if(tools.MetodesJDBC.consultarIdNom(id,nom,"usuarios") != null){
                nombreDB = tools.MetodesJDBC.consultarIdNom(id,nom,"usuarios")[1];
            }
            if(tools.MetodesJDBC.consultarIdNom(id,nom,"grupos") != null){
                grupoDB = tools.MetodesJDBC.consultarIdNom(id,nom,"grupos")[1];
            }
            if (nom.equals(nombreDB) || nom.equals(grupoDB)){
                comprobar =  true;
            }
        } catch (SQLException | IOException ex) {
            Logger.getLogger(MainUsuario.class.getName()).log(Level.SEVERE, null, ex);
        }
        return comprobar;
    }
}