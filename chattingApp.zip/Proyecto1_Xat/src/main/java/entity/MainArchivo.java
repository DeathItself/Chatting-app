/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package entity;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.HashMap;
import java.util.Iterator;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.Socket;
import java.net.SocketException;
import java.nio.file.Files;
import java.sql.SQLException;
import java.sql.SQLIntegrityConstraintViolationException;
import java.util.Scanner;

/**
 *
 *
 */
public class MainArchivo {

    String servidor = "192.168.128.31";
    int puerto = 12345;
    Socket sk;
    FileOutputStream outFile;
    FileInputStream inFile;
    BufferedOutputStream buffOut;
    File fitxer;
    InputStream input;
    String nomFitxer;
    OutputStream out;
    FileOutputStream fout;

    BufferedInputStream buffInput;
    HashMap<Integer, String> listaArchivos = new HashMap<>();
    HashMap<Integer, String> rutaArchivos = new HashMap<>();

    private int emmisor;
    private int receptor = 0;
    private Date fecha;
    private String nomReal;
    private String rutaArxiu;

    //Metodos del servidor para archivos
    public void rebreFitxers2(String nomFitxer) throws IOException, SQLException {
        java.util.Date utilDate = new java.util.Date();
        java.sql.Date fecha = new java.sql.Date(utilDate.getTime());
        int tamany = 10240;
        try {
            input = sk.getInputStream();
            DataInputStream ois = new DataInputStream(input);

            nomFitxer = ois.readUTF();

            String s[] = nomFitxer.split("[\\\\/]");
            nomFitxer = s[s.length - 1];

            String fitxerPrevi = "rebrent_" + nomFitxer;
            long longitud = ois.readLong();

            fitxer = new File(fitxerPrevi);
            fitxer.delete();
            outFile = new FileOutputStream(fitxer);
            buffOut = new BufferedOutputStream(outFile);

            byte b[] = new byte[(int) longitud];

            int rebuts = ois.read(b);
            System.out.println("Rebuts: " + rebuts + " falten " + (longitud - rebuts));

            while (rebuts < longitud) {
                int reci = ois.read(b, rebuts, (int) longitud - rebuts);
                rebuts += reci;
                System.out.println("rebuts: " + reci + " falten " + (longitud - rebuts));
            }
            int identificador = entity.MainArchivo.ultimoId();
            File nouArxiu = new File(identificador + nomFitxer);
            File directorioArchivos = new File("\\directorioArchivos");
            if (!directorioArchivos.exists()) {
                directorioArchivos.mkdir();
                try ( FileOutputStream fileOuputStream = new FileOutputStream(directorioArchivos + "/" + nouArxiu)) {
                    fileOuputStream.write(b);
                    fileOuputStream.close();
                    tools.MetodosArchivos.crearArchivos(2, nomFitxer, nouArxiu.getAbsolutePath());
                } catch (SQLIntegrityConstraintViolationException e) {
                    System.out.println(e.getMessage());
                }
            } else {
                try ( FileOutputStream fileOuputStream = new FileOutputStream(directorioArchivos + "/" + nouArxiu)) {
                    fileOuputStream.write(b);
                    fileOuputStream.close();
                    tools.MetodosArchivos.crearArchivos(2, nomFitxer, nouArxiu.getAbsolutePath());
                } catch (SQLIntegrityConstraintViolationException e) {
                    System.out.println(e.getMessage());
                }
            }
            nouArxiu.delete();
            fitxer.renameTo(nouArxiu);
        } catch (SQLException | IOException ex) {
            Logger.getLogger(MainUsuario.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

    //Metodo que se encarga de listar los archivos que se pueden descargar "Public" 
    public void llistarFitxers2() throws SQLException, IOException {
        listaArchivos = entity.MainArchivo.listaArchivos("Public");
        DataOutputStream llista = new DataOutputStream(sk.getOutputStream());
        String llistaEnviada = "";
        Iterator it = listaArchivos.keySet().iterator();
        while (it.hasNext()) {
            String creador = "";
            Integer key = (Integer) it.next();
            Object[] idArchivos = listaArchivos.keySet().toArray();
            for (int i = 0; i < idArchivos.length; i++) {
                if (key.equals(idArchivos[i])) {
                    creador = tools.MetodosArchivos.compruebaCreador((int) idArchivos[i]);
                }
            }
            llistaEnviada = "Creador: " + creador + " Fitxer: " + listaArchivos.get(key);
            llista.writeUTF(llistaEnviada);
            if (!it.hasNext()) {
                llista.writeUTF("Final de la llista");
            }

        }
    }

    //Metodo para hacer la descarga de los archivos en el cliente
    public void archivosDescarga2() throws IOException {
        int tamano = 1024;
        File directorioArchivos = new File("\\directorioArchivos");
        input = sk.getInputStream();
        buffInput = new BufferedInputStream(input);
        DataInputStream inData = new DataInputStream(input);
        String ruta = inData.readUTF();
        File archivoDescarga = new File(ruta);
        if (archivoDescarga.exists()) {
            out = sk.getOutputStream();
            long longitud = archivoDescarga.length();
            DataOutputStream outData;

            sk.setSoLinger(true, 10);
            outData = new DataOutputStream(out);
            outData.writeLong(longitud);
            File archivo = new File(ruta);
            byte[] bytes = Files.readAllBytes(archivo.toPath());
            out.write(bytes);
            long veces = longitud / tamano;
            System.out.println("Enviat");
            outData.close();

        } else {
            throw new IOException("Error el archivo no existe");
        }

    }

    //Metodo para enviar el archivo seleccionado a otro cliente
    public void enviarArchivos(String nomFitxer) throws SQLException, IOException {
        rebreFitxers2(nomFitxer);
        input = sk.getInputStream();
        int clientReceptor;
        String tipus;
        int arxiu;
        try ( DataInputStream dis = new DataInputStream(input)) {
            clientReceptor = dis.readInt();
            tipus = dis.readUTF();
            arxiu = dis.readInt();
            entity.MainArchivo.sendArchivo(clientReceptor, tipus, arxiu);
            System.out.println("Client receptor rebut");
        }

    }
    //Final de los metodos para archivos del servidor

    //Metodos para el cliente archivos
    //Metodo void para envio de archivos (Cogido del ejercicio de Ivan i modificado)
    public void enviaFitxers(String nomFitxer) throws FileNotFoundException, SocketException, IOException {
        int tamany = 10240;
        try {
            fitxer = new File(nomFitxer);
            input = new FileInputStream(fitxer);
            buffInput = new BufferedInputStream(input);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }

        try {
            out = sk.getOutputStream();
        } catch (IOException e) {
            e.printStackTrace();
        }
        long longitud = fitxer.length();
        DataOutputStream oos;
        try {
            sk.setSoLinger(true, 10);
            oos = new DataOutputStream(out);
            oos.writeUTF(nomFitxer);
            oos.writeLong(longitud);
            long veces = longitud / tamany;

            int restant = (int) (longitud % tamany);
            byte b[] = new byte[tamany];
            for (long i = 0; i < veces; i++) {
                buffInput.read(b);
                out.write(b);
                System.out.println("enviat el tros " + i + " portem enviats " + (i + 1) * tamany + " bytes");
            }
            if (restant > 0) {
                buffInput.read(b, 0, restant);
                out.write(b, 0, restant);
                System.out.println("Bytes restants " + restant + " Enviats");
            }
            System.out.println("Enviat");
        } catch (SocketException e) {
            System.out.println(e.getMessage());
        }

    }

    //Metodo para listar los archivos recibidos de parte del servidor
    public void llistarFitxers() throws IOException {
        DataInputStream entradaArchivos = new DataInputStream(sk.getInputStream());
        String archivo = " ";
        while (!"Final de la llista".equals(archivo)) {
            archivo = entradaArchivos.readUTF();
            System.out.println(archivo);
        }
        entradaArchivos.close();
    }

    //Metodo para descargar los archivos en el cliente recibidos por parte del servidor
    public void descargarArchivos2(String nomFitxer) throws IOException {
        int tamano = 1024;
        out = sk.getOutputStream();
        input = sk.getInputStream();
        DataOutputStream outData = new DataOutputStream(out);
        DataInputStream inData = new DataInputStream(input);
        outData.writeUTF(nomFitxer);
        String archivo = nomFitxer;
        String s[] = archivo.split("[\\\\/]");
        archivo = s[s.length - 1];
        long longitud = inData.readLong();
        System.out.println("Longitud del arxiu: " + longitud);
        fout = new FileOutputStream(archivo);
        buffOut = new BufferedOutputStream(fout);
        byte[] bytes = input.readAllBytes();
        System.out.println("S'han rebut els bytes");
        File directorioDescargas = new File("\\directorioDescargas");
        if (!directorioDescargas.exists()) {
            directorioDescargas.mkdir();
            try ( FileOutputStream fileOuputStream = new FileOutputStream(directorioDescargas + "/" + archivo)) {
                fileOuputStream.write(bytes);
                fileOuputStream.close();
                System.out.println("Descarga completa");
            }
        } else {
            try ( FileOutputStream fileOuputStream = new FileOutputStream(directorioDescargas + "/" + archivo)) {
                fileOuputStream.write(bytes);
                fileOuputStream.close();
                System.out.println("Descarga completa");
            }
        }
        buffOut.close();

    }

    //Metodo para recibir el receptor para el archivo a enviar desde el servidor
    public void enviarReceptor(int receptor, String tipus, int archivo, String nomFitxer) throws IOException {
        Scanner in = new Scanner(System.in);
        enviaFitxers(nomFitxer);
        out = sk.getOutputStream();
        DataOutputStream dos = new DataOutputStream(out);
        dos.writeInt(receptor);
        dos.writeUTF(tipus);
        dos.writeInt(archivo);
        System.out.println("Receptor enviat");
    }

    //Final de los metodos para archivos del cliente
    /**
     * CREAR NUEVO ARCHIVO. Dentro de la DDBB inserta un nuevo registro en
     * FITXERS. Asignar null en atributo Receptor. "El fichero se considera
     * protected" solo visible para el propietario.
     */
    //Metodo de creacion de archivo hacia base de datos
    public void creaArchivo() throws IOException {
        try {
            tools.MetodosArchivos.crearArchivos(getEmmisor(), getNomReal(), getRutaArxiu());
        } catch (SQLException ex) {
            Logger.getLogger(MainArchivo.class.getName()).log(Level.SEVERE, null, ex);
        }

    }

    /**
     * ENVIA UN ARCHIVO.En DDBB FITXERS modifica Receptor con la id del
     * remitente CLIENTE/GRUPO.Si se envia a un cliente "el fichero se considera
     * private" Si se envia a un grupo "el fichero se considera public"
     *
     * @param receptor
     * @param tipus
     * @param arxiu
     */
    public static void sendArchivo(int receptor, String tipus, int arxiu) throws IOException {
        try {
            tools.MetodosArchivos.enviaArchivos(receptor, tipus, arxiu);
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }

    }

    public static void main(String[] args) throws SQLException, IOException {
        int archivo = ultimoId();
        System.out.println(archivo);
    }

    public static int ultimoId() throws SQLException, IOException {
        int ultimoArchivo = 0;
        try ( Connection conexion = tools.ConexionJDBC.conectarJDB()) {
            PreparedStatement ps = conexion.prepareStatement("SELECT id FROM fitxers ORDER BY id desc");
            ps.executeQuery();
            ResultSet rs = ps.getResultSet();
            if (rs.next()) {
                ultimoArchivo = rs.getInt(1) + 1;
            }
        }
        return ultimoArchivo;
    }

//
//    public static String listaPermiso(int id) throws SQLException {
//        String permiso = null;
//        try(Connection conexion = tools.ConexionJDBC.conectarJDB()){
//            PreparedStatement ps = conexion.prepareStatement("SELECT permis FROM fitxers WHERE id = ?");
//            ps.setInt(1, id);
//            ps.executeQuery();
//            ResultSet rs = ps.getResultSet();
//            if(rs.next()){
//              permiso = rs.getString(1);
//            }
//        }
//        
//        return permiso;
//    }
    public static HashMap<Integer, String> listaArchivos(String permiso) throws SQLException, IOException {
        HashMap<Integer, String> listaArchivos = new HashMap<>();
        try ( Connection conexion = tools.ConexionJDBC.conectarJDB()) {
            PreparedStatement ps = conexion.prepareStatement("SELECT id,nomReal FROM fitxers WHERE permis = ?");
            ps.setString(1, permiso);
            ps.executeQuery();
            ResultSet rs = ps.getResultSet();
            while (rs.next()) {
                listaArchivos.put(rs.getInt(1), rs.getString(2));
            }
            rs.close();
            ps.close();
        }

        return listaArchivos;

    }

    /**
     * BORRA UN ARCHIVO. En DDBB FITXERS elimina el registro. Solo cuando la
     * propiedad del fichero coincida con el usuario. Borra el fichero de la
     * carpeta en el servidor.
     */
    /**
     * @return the emmisor
     */
    public int getEmmisor() {
        return emmisor;
    }

    /**
     * @param emmisor the emmisor to set
     */
    public void setEmmisor(int emmisor) {
        this.emmisor = emmisor;
    }

    /**
     * @return the receptor
     */
    public int getReceptor() {
        return receptor;
    }

    /**
     * @param receptor the receptor to set
     */
    public void setReceptor(int receptor) {
        this.receptor = receptor;
    }

    /**
     * @return the fecha
     */
    public Date getFecha() {
        return fecha;
    }

    /**
     * @param fecha the fecha to set
     */
    public void setFecha(Date fecha) {
        this.fecha = fecha;
    }

    /**
     * @return the nomReal
     */
    public String getNomReal() {
        return nomReal;
    }

    /**
     * @param nomReal the nomReal to set
     */
    public void setNomReal(String nomReal) {
        this.nomReal = nomReal;
    }

    /**
     * @return the rutaArxiu
     */
    public String getRutaArxiu() {
        return rutaArxiu;
    }

    /**
     * @param rutaArxiu the rutaArxiu to set
     */
    public void setRutaArxiu(String rutaArxiu) {
        this.rutaArxiu = rutaArxiu;
    }

}
